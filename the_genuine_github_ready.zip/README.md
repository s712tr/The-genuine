# The Genuine – Premium Dating App (Replit Ready)

이 프로젝트는 iOS 스타일 UI/UX와 케미 지수 매칭 알고리즘을 갖춘 프리미엄 데이팅 앱의 백엔드 서버 코드입니다.

## 실행 방법 (Replit)
1. 이 저장소를 Replit에서 **Import from GitHub**로 불러오기
2. 언어(Language) → Nix 선택
3. **Run** 버튼 클릭 (첫 실행 시 자동으로 `pip install -r requirements.txt` 수행)
4. 서버가 실행되면 URL이 표시됩니다.

## 서버 실행 명령어 (직접 실행 시)
```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## API Base URL
Replit에서 실행 시 예: `https://<project>.<username>.repl.co`
