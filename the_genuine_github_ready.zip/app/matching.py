
from pydantic import BaseModel
from typing import List, Dict, Tuple
import numpy as np

class ChemistryModel(BaseModel):
    # Tunable weights
    w_age: float = 0.18
    w_interest: float = 0.30
    w_values: float = 0.20
    w_distance: float = 0.12
    w_activity: float = 0.12   # recent activity / freshness
    w_diversity: float = 0.08  # exposure fairness booster

def jaccard(a: List[str], b: List[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb: return 0.0
    return len(sa & sb) / max(1, len(sa | sb))

def norm_age_gap(a: int, b: int) -> float:
    gap = abs(a - b)
    # 0~4 best, 5~8 okay, after that decays
    if gap <= 4: return 1.0
    return max(0.0, 1.0 - (gap - 4) / 10.0)

def loc_bucket(loc: str) -> str:
    return (loc or "unknown").split(",")[0].strip().lower()

def distance_score(a: str, b: str) -> float:
    # city match = 1.0, else 0.6 baseline
    return 1.0 if loc_bucket(a) == loc_bucket(b) else 0.6

def activity_boost(last_active_minutes: int) -> float:
    # 0~10m:1.0, 60m:0.8, 6h:0.5, 24h+:0.3
    if last_active_minutes <= 10: return 1.0
    if last_active_minutes <= 60: return 0.8
    if last_active_minutes <= 360: return 0.6
    if last_active_minutes <= 1440: return 0.5
    return 0.3

def diversity_boost(exposure_percentile: float) -> float:
    # lower exposure -> stronger boost (0~1 input; 0.0 => 1.0, 1.0 => 0.6)
    exp = np.clip(exposure_percentile, 0.0, 1.0)
    return 1.0 - 0.4 * exp

def score_components(model: ChemistryModel, A, B) -> Dict[str, float]:
    # optional fields with defaults
    a_last = getattr(B, "last_active_minutes", 60)
    a_exp = getattr(B, "exposure_percentile", 0.5)

    return {
        "age": norm_age_gap(A.age, B.age),
        "interests": jaccard(A.interests, B.interests),
        "values": jaccard(A.values, B.values),
        "distance": distance_score(A.location, B.location),
        "activity": activity_boost(a_last),
        "diversity": diversity_boost(a_exp),
    }

def weighted_sum(model: ChemistryModel, comps: Dict[str, float]) -> float:
    return (
        model.w_age * comps["age"] +
        model.w_interest * comps["interests"] +
        model.w_values * comps["values"] +
        model.w_distance * comps["distance"] +
        model.w_activity * comps["activity"] +
        model.w_diversity * comps["diversity"]
    )

def score_pair(model: ChemistryModel, A, B) -> float:
    comps = score_components(model, A, B)
    score = weighted_sum(model, comps)
    return float(100.0 * np.clip(score, 0.0, 1.0))

def score_pair_explain(model: ChemistryModel, A, B) -> Tuple[float, Dict[str, float]]:
    comps = score_components(model, A, B)
    # contribution in 0~100 scale
    contrib = {
        k: float(100.0 * v * getattr(model, f"w_{'interest' if k=='interests' else k}"))
        for k, v in comps.items()
    }
    total = float(sum(contrib.values()))
    return float(np.clip(total, 0.0, 100.0)), contrib
