from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from typing import List, Dict
from app.matching import ChemistryModel, score_pair


from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="The Genuine Backend", version="0.0.2")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Profile(BaseModel):
    user_id: str
    age: int
    gender: str
    interests: List[str]
    values: List[str]
    location: str

# in-memory demo store
PROFILES: Dict[str, Profile] = {}
chem = ChemistryModel()

@app.post("/profile")
def upsert_profile(p: Profile):
    PROFILES[p.user_id] = p
    return {"ok": True}

@app.get("/recommend/{user_id}")
def recommend(user_id: str, topk: int = 10):
    target = PROFILES.get(user_id)
    if not target:
        return {"results": []}
    scores = []
    for uid, p in PROFILES.items():
        if uid == user_id:
            continue
        s = score_pair(chem, target, p)
        scores.append((uid, s))
    scores.sort(key=lambda x: x[1], reverse=True)
    return {"results": [{"user_id": uid, "chemistry": float(s)} for uid, s in scores[:topk]]}

# naive WebSocket signaling placeholder (NOT production ready)
peers: Dict[str, WebSocket] = {}

@app.websocket("/ws/{user_id}")
async def websocket_endpoint(ws: WebSocket, user_id: str):
    await ws.accept()
    peers[user_id] = ws
    try:
        while True:
            data = await ws.receive_text()
            # data should be JSON SDP/ICE and target
            for uid, sock in peers.items():
                if uid != user_id:
                    await sock.send_text(data)
    except WebSocketDisconnect:
        peers.pop(user_id, None)


class RecommendResponse(BaseModel):
    user_id: str
    chemistry: float
    contributions: Dict[str, float]

@app.get("/explain/{user_id}")
def explain(user_id: str, topk: int = 10):
    target = PROFILES.get(user_id)
    if not target:
        return {"results": []}
    results = []
    for uid, p in PROFILES.items():
        if uid == user_id:
            continue
        s, contrib = score_pair_explain(chem, target, p)
        results.append({"user_id": uid, "chemistry": float(s), "contributions": contrib})
    results.sort(key=lambda x: x["chemistry"], reverse=True)
    return {"results": results[:topk]}
