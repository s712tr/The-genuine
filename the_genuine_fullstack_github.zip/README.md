# The Genuine – Fullstack Web (Replit Ready)

- iOS 감성 웹 프론트 + FastAPI 백엔드(케미 지수 v2)
- Replit에서 **Run** 버튼 한 번으로 실행
- 점수 표기는 **% (퍼센트)** 기준

## Replit 실행
1) GitHub에서 이 저장소를 만든 뒤 이 파일들을 업로드
2) Replit 앱/웹 → **Import from GitHub**
3) 언어: **Nix**
4) **Run** → `/api/*`와 `/`(웹)가 동시에 켜집니다

## API
- `POST /api/profile` – 프로필 업서트
- `GET /api/recommend/me` – 추천
- `GET /api/explain/me` – 기여도(설명)
