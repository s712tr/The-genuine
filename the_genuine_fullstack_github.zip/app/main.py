
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Dict, Tuple, Optional
import numpy as np

# -------- Data Models --------
class Profile(BaseModel):
    user_id: str
    age: int
    gender: Optional[str] = None
    interests: List[str] = []
    values: List[str] = []
    location: Optional[str] = "Seoul, KR"
    last_active_minutes: int = 60
    exposure_percentile: float = 0.5
    education: Optional[str] = None
    workplace: Optional[str] = None

PROFILES: Dict[str, Profile] = {}

# -------- Chemistry v2 --------
class ChemistryModel(BaseModel):
    w_age: float = 0.18
    w_interest: float = 0.30
    w_values: float = 0.20
    w_distance: float = 0.12
    w_activity: float = 0.12
    w_diversity: float = 0.08

def jaccard(a: List[str], b: List[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb: return 0.0
    return len(sa & sb) / max(1, len(sa | sb))

def norm_age_gap(a: int, b: int) -> float:
    gap = abs(a - b)
    if gap <= 4: return 1.0
    return max(0.0, 1.0 - (gap - 4) / 10.0)

def loc_bucket(loc: str) -> str:
    return (loc or "unknown").split(",")[0].strip().lower()

def distance_score(a: str, b: str) -> float:
    return 1.0 if loc_bucket(a) == loc_bucket(b) else 0.6

def activity_boost(last_active_minutes: int) -> float:
    if last_active_minutes <= 10: return 1.0
    if last_active_minutes <= 60: return 0.8
    if last_active_minutes <= 360: return 0.6
    if last_active_minutes <= 1440: return 0.5
    return 0.3

def diversity_boost(exposure_percentile: float) -> float:
    exp = float(np.clip(exposure_percentile, 0.0, 1.0))
    return 1.0 - 0.4 * exp

def score_components(model: ChemistryModel, A: Profile, B: Profile) -> Dict[str, float]:
    return {
        "age": norm_age_gap(A.age, B.age),
        "interests": jaccard(A.interests, B.interests),
        "values": jaccard(A.values, B.values),
        "distance": distance_score(A.location or "", B.location or ""),
        "activity": activity_boost(B.last_active_minutes),
        "diversity": diversity_boost(B.exposure_percentile),
    }

def score_pair_explain(model: ChemistryModel, A: Profile, B: Profile) -> Tuple[float, Dict[str, float]]:
    comps = score_components(model, A, B)
    contrib = {
        k: float(100.0 * v * getattr(model, f"w_{'interest' if k=='interests' else k}"))
        for k, v in comps.items()
    }
    total = float(sum(contrib.values()))
    return float(np.clip(total, 0.0, 100.0)), contrib

chem = ChemistryModel()

# -------- FastAPI App --------
app = FastAPI(title="The Genuine Fullstack", version="1.0.1")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/profile")
def upsert_profile(p: Profile):
    PROFILES[p.user_id] = p
    return {"ok": True}

@app.get("/api/recommend/{user_id}")
def recommend(user_id: str, topk: int = 10):
    target = PROFILES.get(user_id)
    if not target:
        return {"results": []}
    results = []
    for uid, p in PROFILES.items():
        if uid == user_id: continue
        s, _ = score_pair_explain(chem, target, p)
        results.append({"user_id": uid, "chemistry": float(s)})
    results.sort(key=lambda x: x["chemistry"], reverse=True)
    return {"results": results[:topk]}

@app.get("/api/explain/{user_id}")
def explain(user_id: str, topk: int = 10):
    target = PROFILES.get(user_id)
    if not target:
        return {"results": []}
    results = []
    for uid, p in PROFILES.items():
        if uid == user_id: continue
        s, contrib = score_pair_explain(chem, target, p)
        results.append({"user_id": uid, "chemistry": float(s), "contributions": contrib})
    results.sort(key=lambda x: x["chemistry"], reverse=True)
    return {"results": results[:topk]}

# Static web mount
from fastapi.staticfiles import StaticFiles
app.mount("/", StaticFiles(directory="web", html=True), name="web")
