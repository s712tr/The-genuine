// Minimal iOS-like SPA with Health-style chart (percent display)
const API = '/api';
const chipsData = ['하이킹','재즈','커피','테니스','클라이밍','디자인','개발','요리','영화','독서'];
const chipsEl = document.getElementById('chips');
const views = {
  onboarding: document.getElementById('view-onboarding'),
  profile: document.getElementById('view-profile'),
  results: document.getElementById('view-results'),
};

function show(id) {
  Object.values(views).forEach(v => v.classList.remove('active'));
  views[id].classList.add('active');
  window.scrollTo({ top:0, behavior:'smooth' });
}

document.getElementById('btn-start').onclick = () => show('profile');
document.getElementById('btn-back-1').onclick = () => show('onboarding');
document.getElementById('btn-back-2').onclick = () => show('profile');
document.getElementById('btn-refresh').onclick = () => runRecommend();

// Render chips
const selected = new Set();
chipsData.forEach(tag => {
  const b = document.createElement('button');
  b.className = 'chip';
  b.textContent = tag;
  b.onclick = () => { b.classList.toggle('active'); selected.has(tag) ? selected.delete(tag) : selected.add(tag); };
  chipsEl.appendChild(b);
});

// Submit profile
document.getElementById('btn-submit').onclick = async () => {
  const me = {
    user_id: 'me',
    age: parseInt(document.getElementById('age').value || '0', 10),
    gender: 'U',
    interests: Array.from(selected),
    values: ['진정성','배려'],
    location: 'Seoul, KR',
    last_active_minutes: 3,
    exposure_percentile: 0.5,
    education: document.getElementById('education').value || '',
    workplace: document.getElementById('workplace').value || '',
  };
  if (!me.age) { alert('나이를 입력해 주세요'); return; }
  await fetch(`${API}/profile`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(me)});
  // seed
  const others = [
    {user_id:'a', age:28, gender:'F', interests:['하이킹','디자인','커피'], values:['진정성','유머'], location:'Seoul, KR', last_active_minutes:8, exposure_percentile:0.8},
    {user_id:'b', age:34, gender:'F', interests:['클라이밍','재즈'], values:['성실','배려'], location:'Incheon, KR', last_active_minutes:120, exposure_percentile:0.2},
    {user_id:'c', age:27, gender:'F', interests:['하이킹','테니스'], values:['진정성'], location:'Seoul, KR', last_active_minutes:1440, exposure_percentile:0.9},
  ];
  for (const p of others) { await fetch(`${API}/profile`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(p)}); }
  await runRecommend();
  show('results');
};

// Results: list + chart
const cardsEl = document.getElementById('cards');
const scoreEl = document.getElementById('score');
const canvas = document.getElementById('chart');
const ctx = canvas.getContext('2d');
let chartState = { target: {interests:0, values:0, age:0, distance:0, activity:0, diversity:0}, anim: {t:0} };

async function runRecommend() {
  const [recRes, expRes] = await Promise.all([
    fetch(`${API}/recommend/me`).then(r=>r.json()),
    fetch(`${API}/explain/me`).then(r=>r.json()),
  ]);
  const items = recRes.results || [];
  const details = expRes.results || [];
  renderCards(items, details);
  if (items[0]) {
    const d = details.find(x => x.user_id === items[0].user_id) || {contributions:{}};
    const contrib = d.contributions || {};
    animateTo(contrib, items[0].chemistry);
  }
}

function renderCards(items, details) {
  cardsEl.innerHTML = '';
  items.forEach(e => {
    const d = details.find(x => x.user_id === e.user_id) || {contributions:{}};
    const c = d.contributions || {};
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="meta">
        <div style="font-weight:600">상대: ${e.user_id}</div>
        <div style="color:#6b7280">공통관심·가치·거리 기반</div>
      </div>
      <div class="pill">케미 ${Math.round(e.chemistry)}%</div>
    `;
    card.onclick = () => animateTo(c, e.chemistry);
    cardsEl.appendChild(card);
  });
}

// Health-like smooth bar chart (with gradient and glossy overlay)
function animateTo(contrib, totalScore) {
  scoreEl.textContent = Math.round(totalScore || 0);
  const keys = ['interests','values','age','distance','activity','diversity'];
  const max = 100.0;
  const target = {};
  keys.forEach(k => target[k] = (contrib[k] || 0) / max);
  chartState.target = target;
  chartState.anim.t = 0;
}

function draw() {
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0,0,w,h);

  // grid
  ctx.globalAlpha = 0.6;
  ctx.strokeStyle = '#e5e5ea';
  ctx.lineWidth = 1;
  for (let i=0;i<=5;i++) {
    const y = 24 + i*((h-48)/5);
    ctx.beginPath(); ctx.moveTo(16,y); ctx.lineTo(w-16,y); ctx.stroke();
  }
  ctx.globalAlpha = 1;

  const keys = ['공통 관심사','가치관','나이','거리','신선도','노출 균형'];
  const mapKeys = ['interests','values','age','distance','activity','diversity'];

  // easing
  const t = chartState.anim.t;
  const ease = (x)=>1- Math.pow(1-x,3);
  const prog = ease(Math.min(1, t));

  const baseX = 110, barW = (w - baseX - 24);
  for (let i=0;i<mapKeys.length;i++) {
    const k = mapKeys[i];
    const label = keys[i];
    const y = 24 + i * ((h-48)/5);

    const tv = (chartState.target[k] || 0);
    const cur = tv * prog;

    // label
    ctx.fillStyle = '#111';
    ctx.font = '14px -apple-system, BlinkMacSystemFont, "SF Pro Text"';
    ctx.textAlign = 'right';
    ctx.fillText(label, baseX-12, y+5);

    // base bar
    const x = baseX, height = 12, radius = 6;
    roundRect(ctx, x, y-6, barW, height, radius, '#e5e5ea');

    // foreground bar
    roundRect(ctx, x, y-6, barW*cur, height, radius, null, true);

    // value text (percent)
    ctx.textAlign = 'left';
    ctx.fillStyle = '#6b7280';
    ctx.fillText(`${Math.round(tv*100)}%`, x + barW + 6, y+5);
  }

  if (chartState.anim.t < 1) chartState.anim.t += 0.04;
  requestAnimationFrame(draw);
}

function roundRect(ctx, x, y, w, h, r, fill, gradient=false) {
  ctx.beginPath();
  ctx.moveTo(x+r, y);
  ctx.arcTo(x+w, y, x+w, y+h, r);
  ctx.arcTo(x+w, y+h, x, y+h, r);
  ctx.arcTo(x, y+h, x, y, r);
  ctx.arcTo(x, y, x+w, y, r);
  ctx.closePath();
  if (gradient) {
    const g = ctx.createLinearGradient(x, y, x+w, y);
    g.addColorStop(0, 'rgba(10,132,255,0.95)');
    g.addColorStop(1, 'rgba(10,132,255,0.65)');
    ctx.fillStyle = g;
    ctx.fill();
    const g2 = ctx.createLinearGradient(x, y, x, y+h);
    g2.addColorStop(0, 'rgba(255,255,255,0.35)');
    g2.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g2;
    ctx.fill();
  } else {
    ctx.fillStyle = fill || '#e5e5ea';
    ctx.fill();
  }
}

draw();
