# FastAPI backend placeholder
